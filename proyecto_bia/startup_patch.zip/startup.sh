#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="/home/site/wwwroot"
LATEST_TMP="$(ls -td /tmp/* 2>/dev/null | head -1 || true)"
if [ -n "${LATEST_TMP}" ] && [ -f "${LATEST_TMP}/manage.py" ]; then
  APP_ROOT="${LATEST_TMP}"
fi
cd "${APP_ROOT}"

[ -f /home/site/wwwroot/output.tar.gz ] && rm -f /home/site/wwwroot/output.tar.gz || true

export WEB_CONCURRENCY="${WEB_CONCURRENCY:-1}"
export GUNICORN_TIMEOUT="${GUNICORN_TIMEOUT:-180}"
export PYTHONUNBUFFERED=1
PORT="${PORT:-8000}"

unset GUNICORN_CMD_ARGS || true
unset ORYX_ARGS || true

echo "[startup] applying migrations..."
python manage.py migrate --noinput

echo "[startup] collectstatic..."
python manage.py collectstatic --noinput

echo "[startup] starting gunicorn..."
set --

exec python -m gunicorn --bind 0.0.0.0:${PORT} --workers ${WEB_CONCURRENCY} --timeout ${GUNICORN_TIMEOUT} --max-requests 200 --max-requests-jitter 50 --log-level info proyecto_bia.wsgi:application
